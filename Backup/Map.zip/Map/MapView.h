// MapView.h : interface of the CMapView class
//
/////////////////////////////////////////////////////////////////////////////
struct mark
{
	double distance;//�洢����ֵ
    int x;
	int y;
	double w;//Ȩ��
	int n;//���
};
struct point
{
	int x;
	int y;
	double w;
};
#if !defined(AFX_MAPVIEW_H__44F9F8F7_BB43_442C_9C44_021AE8D035E5__INCLUDED_)
#define AFX_MAPVIEW_H__44F9F8F7_BB43_442C_9C44_021AE8D035E5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "DIB.h"

class CMapView : public CView
{
protected: // create from serialization only
	CMapView();
	DECLARE_DYNCREATE(CMapView)

// Attributes
public:
	CMapDoc* GetDocument();

// Operations
public:
CDIB *m_pdib;
double distance[804][484];
mark T[1000][1000];
point m_point[90];
int m;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMapView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	void digui(int i,int j);
	CPoint p;
	int max_x;
	int max_y;
	int m_chufa;//���ƿ���
	
	
	virtual ~CMapView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMapView)
	afx_msg void OnRasterIn();
	afx_msg void OnDistance();
	afx_msg void OnVector();
	afx_msg void OnDistanceSg();
	afx_msg void OnRidge();
	afx_msg void OnUpdateXY(CCmdUI* pCmdUI);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnDistanceY();
	afx_msg void OnAll();
	afx_msg void OnAllV();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MapView.cpp
inline CMapDoc* CMapView::GetDocument()
   { return (CMapDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAPVIEW_H__44F9F8F7_BB43_442C_9C44_021AE8D035E5__INCLUDED_)
