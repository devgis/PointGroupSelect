// MapView.cpp : implementation of the CMapView class
//

#include "stdafx.h"
#include "Map.h"
#include "MainFrm.h"
#include <fstream.h>

#include "Math.h"
#include "MapDoc.h"
#include "MapView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMapView

IMPLEMENT_DYNCREATE(CMapView, CView)

BEGIN_MESSAGE_MAP(CMapView, CView)
	//{{AFX_MSG_MAP(CMapView)
	ON_COMMAND(ID_RASTER_IN, OnRasterIn)
	ON_COMMAND(ID_DISTANCE, OnDistance)
	ON_COMMAND(ID_VECTOR, OnVector)
	ON_COMMAND(ID_DISTANCE_SG, OnDistanceSg)
	ON_COMMAND(ID_RIDGE, OnRidge)
	ON_UPDATE_COMMAND_UI(ID_LEFT, OnUpdateXY)
	ON_WM_MOUSEMOVE()
	ON_COMMAND(ID_DISTANCE_Y, OnDistanceY)
	ON_COMMAND(ID_ALL, OnAll)
	ON_UPDATE_COMMAND_UI(ID_RIGHT, OnUpdateXY)
	ON_UPDATE_COMMAND_UI(ID_RGB, OnUpdateXY)
	ON_COMMAND(ID_ALL_V, OnAllV)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMapView construction/destruction

CMapView::CMapView()
{
	// TODO: add construction code here
    m_pdib=new CDIB;
    
	m_chufa=0;


}

CMapView::~CMapView()
{
}

BOOL CMapView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMapView drawing

void CMapView::OnDraw(CDC* pDC)
{
	CMapDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	if(m_chufa==1)
	{
		if(m_pdib==NULL || m_pdib->m_pBMI==NULL || m_pdib->m_pDIBData==NULL) return;

	CRect rect;
	GetClientRect(rect);
	m_pdib->ShowDIB(pDC,2,2,400,240);
	}
	else
	{
		if(m_chufa==2)
		{    
			int i=0;
			for(i=0;i<m;i++)
            pDC->SetPixel(m_point[i].x,m_point[i].y,RGB(m_point[i].w*10,0,0));
		}
	}
	//m_pdib->ShowDIB(pDC,0,0,rect.Width(),rect.Height());
}

/////////////////////////////////////////////////////////////////////////////
// CMapView printing

BOOL CMapView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMapView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMapView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CMapView diagnostics

#ifdef _DEBUG
void CMapView::AssertValid() const
{
	CView::AssertValid();
}

void CMapView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMapDoc* CMapView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMapDoc)));
	return (CMapDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMapView message handlers

void CMapView::OnRasterIn() 
{
	// TODO: Add your command handler code here
		CString fileName;
	
	static char szbuf[]="BMP(*.bmp)|*.bmp||";
	CFileDialog FileDlg(TRUE,"bmp","Test",OFN_HIDEREADONLY,szbuf);

	//------------------------------------------
	if(FileDlg.DoModal()==IDOK) {
		fileName=FileDlg.GetPathName();
		if(!m_pdib->LoadFromFile(fileName))
			return;
		Invalidate(FALSE);
	}
	m_chufa=1;

	max_x=400;
	max_y=240;
}

void CMapView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	if(!m_pdib->LoadFromFile("E:\\��ͼDATA\\CHINA.bmp"))
		return;
	Invalidate(FALSE);
	
}

void CMapView::OnDistance() 
{
	// TODO: Add your command handler code here
	CClientDC DC(this);
	COLORREF BS=RGB(255,255,255);
	int i;
	int j;

	
	
	//DC.TextOut(500,100,"FAS");
	
	
	for(i=0;i<max_x+4;i++)
		for(j=0;j<max_y+4;j++)
		{
			if (DC.GetPixel(i,j)==BS)
				
				distance[i][j]=50625;//����ֵ��ֵΪ����ֵ255
			
			
			else
			{	
			distance[i][j]=0;//Ŀ����Ԫ������ֵ��ֵΪ0��
			if(distance[i-1][j]>1)
				distance[i-1][j]=1;
			if(distance[i+1][j]>1)
				distance[i+1][j]=1;
			if(distance[i][j-1]>1)
				distance[i][j-1]=1;
			if(distance[i][j+1]>1)
				distance[i][j+1]=1;
			if(distance[i+1][j+1]>2)
				distance[i+1][j+1]=2;
			if(distance[i-1][j+1]>2)
				distance[i-1][j+1]=2;
			if(distance[i+1][j-1]>2)
				distance[i+1][j-1]=2;
            if(distance[i-1][j-1]=2)
				distance[i-1][j-1]=2;
		
			}
			
			DC.SetPixel(i,j,RGB(distance[i][j],0,0));
		}
     for(i=0;i<max_x+4;i++)
		for(j=0;j<max_y+4;j++)
		{
			if(distance[i][j]==0)
			{
			distance[i-1][j]=1;
			distance[i+1][j]=1;
			distance[i][j-1]=1;
			distance[i][j+1]=1;
			distance[i+1][j+1]=2;
			distance[i-1][j+1]=2;
			distance[i+1][j-1]=2;
			distance[i-1][j-1]=2;
			}

		}
		MessageBox("��ʼ������");
		
		for(i=2;i<max_x+1;i++)	
			for(j=2;j<max_y+1;j++)
				
				
			{   	
				double de[8]={50625,50625,50625,50625,50625,50625,50625,50625};

			
					if(distance[i][j-1]>distance[i][j-2])
					de[0]=(2*distance[i][j-1]-distance[i][j-2]+2);							
			
					if(distance[i-1][j-1]>distance[i-2][j-2])
					de[1]=(2*distance[i-1][j-1]-distance[i-2][j-2]+4);
					if(distance[i-1][j-1]<distance[i-1][j]&&distance[i-1][j-1]<distance[i][j-1])
					de[4]=distance[i-1][j]+distance[i][j-1]-distance[i-1][j-1];
					//if(distance[i-1][j-1]>distance[i-2][j-1]&&distance[i-1][j-1]>distance[i-1][j-2])
					//de[6]=3*distance[i-1][j-1]-distance[i-2][i-1]-distance[i-1][j-2]+4;
			
					if(distance[i-1][j]>distance[i-2][j])
					de[2]=(2*distance[i-1][j]-distance[i-2][j]+2);
			
					if(distance[i-1][j+1]>distance[i-2][j+2])
					de[3]=(2*distance[i-1][j+1]-distance[i-2][j+2]+4);
					if(distance[i-1][j+1]<distance[i-1][j]&&distance[i-1][j+1]<distance[i][j+1])
					de[5]=distance[i-1][j]+distance[i][j+1]-distance[i-1][j+1];
					//if(distance[i-1][j+1]>distance[i-2][j+1]&&distance[i-1][j+1]>distance[i-1][j+2])
					//de[7]=3*distance[i-1][j+1]-distance[i-2][i+1]-distance[i-1][j+2]+4;
					
				
					
				int k=0;
			
				for(k=0;k<8;k++)
				{   
					if(de[k]<distance[i][j])
					{
						distance[i][j]=de[k];
					}
				}
				
				
			//	DC.SetPixel(i,j,RGB(int(sqrt(distance[i][j])+0.5),0,0));
				DC.SetPixel(i,j,RGB(int(sqrt(distance[i][j])+0.5),int(sqrt(distance[i][j])+0.5),int(sqrt(distance[i][j])+0.5)));
			}//����ɨ��

			MessageBox("����ɨ�����");
			/*CFileDialog fileDlg1(FALSE);
			fileDlg1.m_ofn.lpstrTitle="����Ի���";
			fileDlg1.m_ofn.lpstrFilter="Text Files(*.txt)\0*.txt\0All Files(*.*)\0*.*\0\0";
			fileDlg1.m_ofn.lpstrDefExt="txt";
			if(IDOK==fileDlg1.DoModal())
			{
				CString filefullname=fileDlg1.GetPathName();
				ofstream file(filefullname);
				MessageBox(filefullname);
			
		for(j=2;j<100;j++)
		{
				CString   str;
				str.Format("%-5d",j);   
					file<<str<<" ";
				for(i=250;i<350;i++)
			{       
			       
					CString   str;   
					str.Format("%-5d",int(distance[i][j]));   
					file<<str<<" ";
							
				}
				file<<"\n";
				
			
		}
			}//��������*/
			
			
			
			for(i=max_x;i>1;i--)
				for(j=max_y;j>1;j--)
				{
					double de[6]={50625,50625,50625,50625,50625,50625};
										
				
				
						if(distance[i][j+1]>distance[i][j+2])
						de[0]=(2*distance[i][j+1]-distance[i][j+2]+2);
				
						if(distance[i+1][j+1]>distance[i+2][j+2])
					    de[1]=(2*distance[i+1][j+1]-distance[i+2][j+2]+4);
						if(distance[i+1][j+1]<distance[i+1][j]&&distance[i+1][j+1]<distance[i][j+1])
					    de[4]=distance[i+1][j]+distance[i][j+1]-distance[i+1][j+1];
				 		
				
						if(distance[i+1][j]>distance[i+2][j])
						de[2]=(2*distance[i+1][j]-distance[i+2][j]+2);
						
				
						if(distance[i+1][j-1]>distance[i+2][j-2])						
						de[3]=(2*distance[i+1][j-1]-distance[i+2][j-2]+4);
						if(distance[i+1][j-1]<distance[i+1][j]&&distance[i+1][j-1]<distance[i][j-1])
					    de[5]=distance[i+1][j]+distance[i][j-1]-distance[i+1][j-1];
						
					
			        int k=0;
					for(k=0;k<6;k++)
					{   
						
						if(de[k]<distance[i][j])
						{
							distance[i][j]=de[k];
						}
					}
					
				//	DC.SetPixel(i,j,RGB(int(sqrt(distance[i][j])+0.5),0,0));
					DC.SetPixel(i,j,RGB(int(sqrt(distance[i][j])+0.5),int(sqrt(distance[i][j])+0.5),int(sqrt(distance[i][j])+0.5)));
				}//����ɨ��
			
				MessageBox("����ɨ�����");
				
			
		
				/*for(i=2;i<max_x;i++)
				for(j=2;j<max_y;j++)
				{
					DC.SetPixel(i,j,RGB(int(sqrt(distance[i][j])+0.5),0,0));
				}
				MessageBox("����");*/
}

void CMapView::OnVector() 
{
	// TODO: Add your command handler code here
	//int m=0;
	CFileDialog fileDlg(TRUE);
	fileDlg.m_ofn.lpstrTitle="�ҵ��ļ��򿪶Ի���";
	fileDlg.m_ofn.lpstrFilter="Text Files(*.txt)\0*.txt\0All Files(*.*)\0*.*\0\0";
	
	
	if(IDOK==fileDlg.DoModal())
	{    
		CString filefullname=fileDlg.GetPathName();
		ifstream file(filefullname);
		int i=0;
		file>>m;
	
		
		for(i=0;i<m;i++)
		{   
			file>>m_point[i].x;
			file>>m_point[i].y;
			file>>m_point[i].w;
		
			
		}
	
		//free(p);
		
	}
    max_x=400;
	max_y=240;
	m_chufa=2;	
	Invalidate(TRUE);
	
}

void CMapView::OnDistanceSg() 
{
	// TODO: Add your command handler code here
	CClientDC DC(this);
	COLORREF BS=RGB(255,255,255);
	int i;
	int j;
	mark de[9];
	
	//DC.TextOut(500,100,"FAS");
	
	if(m_chufa==1)
	{
	for(i=0;i<max_x+3;i++)
		for(j=0;j<max_y+3;j++)
		{
			if (DC.GetPixel(i,j)==BS)
				
			{
				T[i][j].distance=50625;//����ֵ��ֵΪ����ֵ255
                T[i][j].x=50625;
				T[i][j].y=50625;
				T[i][j].w=1;
			}
			
			else
			{
				T[i][j].distance=0;//Ŀ��㸳0
                T[i][j].x=i;
				T[i][j].y=j;
				T[i][j].w=1;
			}
			
		}
	}
	
		if(m_chufa==2)
		{
           for(i=0;i<max_x+3;i++)
		      for(j=0;j<max_y+3;j++)
			  {
                T[i][j].distance=50625;//����ֵ��ֵΪ����ֵ255
                T[i][j].x=50625;
				T[i][j].y=50625;
				T[i][j].w=1;

			  }
			  for(i=0;i<m;i++)
			  {
				  T[m_point[i].x][m_point[i].y].x=m_point[i].x;
				  T[m_point[i].x][m_point[i].y].y=m_point[i].y;
				  T[m_point[i].x][m_point[i].y].w=m_point[i].w;
				  T[m_point[i].x][m_point[i].y].distance=0;


			  }
		}
		if(m_chufa==3)
		{
			for(i=0;i<max_x+3;i++)
		for(j=0;j<max_y+3;j++)
		{
			if (DC.GetPixel(i,j)==BS)
				
			{
				T[i][j].distance=50625;//����ֵ��ֵΪ����ֵ255
                T[i][j].x=50625;
				T[i][j].y=50625;
				T[i][j].w=1;
			}
			
			else
			{
				T[i][j].distance=0;//Ŀ��㸳0
                T[i][j].x=i;
				T[i][j].y=j;
				T[i][j].w=1;
			}
			
		}
		}

		MessageBox("��ʼ������fdsafasf");
		
		for(i=2;i<max_x+1;i++)
			for(j=2;j<max_y+1;j++)
			{
				
				    de[1].distance=sqrt((i-T[i][j-1].x)*(i-T[i][j-1].x)+(j-T[i][j-1].y)*(j-T[i][j-1].y))/T[i][j-1].w;
					de[1].x=T[i][j-1].x;
					de[1].y=T[i][j-1].y;
					de[1].w=T[i][j-1].w;


					de[2].distance=sqrt((i-T[i-1][j-1].x)*(i-T[i-1][j-1].x)+(j-T[i-1][j-1].y)*(j-T[i-1][j-1].y))/T[i-1][j-1].w;
                    de[2].x=T[i-1][j-1].x;
					de[2].y=T[i-1][j-1].y;
					de[2].w=T[i-1][j-1].w;
						
					de[3].distance=sqrt((i-T[i-1][j].x)*(i-T[i-1][j].x)+(j-T[i-1][j].y)*(j-T[i-1][j].y))/T[i-1][j].w;
                    de[3].x=T[i-1][j].x;
					de[3].y=T[i-1][j].y;
					de[3].w=T[i-1][j].w;

					de[4].distance=sqrt((i-T[i-1][j+1].x)*(i-T[i-1][j+1].x)+(j-T[i-1][j+1].y)*(j-T[i-1][j+1].y))/T[i-1][j+1].w;
					de[4].x=T[i-1][j+1].x;
					de[4].y=T[i-1][j+1].y;
					de[4].w=T[i-1][j+1].w;

					
				
					
				
				
				int k=0;
				for(k=1;k<5;k++)
				{
					if(de[k].distance<T[i][j].distance)
					{
						T[i][j].distance=de[k].distance;
                        T[i][j].x=de[k].x;
						T[i][j].y=de[k].y;
						T[i][j].w=de[k].w;


					}
				}
			//	DC.SetPixel(i,j,RGB(int(T[i][j].distance+0.5),0,0));
                	DC.SetPixel(i,j,RGB(int(T[i][j].distance+0.5),int(T[i][j].distance+0.5),int(T[i][j].distance+0.5)));
			}//����ɨ��
			//MessageBox("����ɨ�����");
			for(i=max_x;i>1;i--)
				for(j=max_y;j>1;j--)
				{
					
					
					de[5].distance=sqrt((i-T[i][j+1].x)*(i-T[i][j+1].x)+(j-T[i][j+1].y)*(j-T[i][j+1].y))/T[i][j+1].w;
					de[5].x=T[i][j+1].x;
					de[5].y=T[i][j+1].y;
					de[5].w=T[i][j+1].w;

					de[6].distance=sqrt((i-T[i+1][j+1].x)*(i-T[i+1][j+1].x)+(j-T[i+1][j+1].y)*(j-T[i+1][j+1].y))/T[i+1][j+1].w;
					de[6].x=T[i+1][j+1].x;
					de[6].y=T[i+1][j+1].y;
					de[6].w=T[i+1][j+1].w;

					de[7].distance=sqrt((i-T[i+1][j].x)*(i-T[i+1][j].x)+(j-T[i+1][j].y)*(j-T[i+1][j].y))/T[i+1][j].w;
					de[7].x=T[i+1][j].x;
					de[7].y=T[i+1][j].y;
					de[7].w=T[i+1][j].w;

					de[8].distance=sqrt((i-T[i+1][j-1].x)*(i-T[i+1][j-1].x)+(j-T[i+1][j-1].y)*(j-T[i+1][j-1].y))/T[i+1][j-1].w;
					de[8].x=T[i+1][j-1].x;
					de[8].y=T[i+1][j-1].y;
					de[8].w=T[i+1][j-1].w;
					
					int k=0;
					for(k=5;k<9;k++)
					{
					if(de[k].distance<T[i][j].distance)
					{
						T[i][j].distance=de[k].distance;
                        T[i][j].x=de[k].x;
						T[i][j].y=de[k].y;
						T[i][j].w=de[k].w;


					}
					}
				
					//	DC.SetPixel(i,j,RGB(int(T[i][j].distance+0.5),0,0));
							DC.SetPixel(i,j,RGB(int(T[i][j].distance+0.5),int(T[i][j].distance+0.5),int(T[i][j].distance+0.5)));
				}//����ɨ�衣���ɾ���任ͼ

				MessageBox("����vͼ");
			
				
				for(i=2;i<max_x+1;i++)
					for(j=2;j<max_y+1;j++)
					{
						DC.SetPixel(i,j,RGB(T[i][j].x,T[i][j].y,0));
					}
				MessageBox("��ȡ�߽�");

				for(i=2;i<max_x+1;i++)
				for(j=2;j<max_y+1;j++)
					
				if(!((T[i][j].x==T[i][j+1].x)&&(T[i][j].y==T[i][j+1].y)))
						DC.SetPixel(i,j,0);
				
				for(j=2;j<max_y+1;j++)
				for(i=2;i<max_x+1;i++)	
				if(!((T[i][j].x==T[i+1][j].x)&&(T[i][j].y==T[i+1][j].y)))
						DC.SetPixel(i,j,0);
					/*for(i=2;i<max_x+1;i++)
				for(j=2;j<max_y+1;j++)
					
				if(DC.GetPixel(i,j)!=DC.GetPixel(i,j+1))
						DC.SetPixel(i,j,0);
				
				for(j=2;j<max_y+1;j++)
				for(i=2;i<max_x+1;i++)	
				if(DC.GetPixel(i,j)!=DC.GetPixel(i+1,j))
						DC.SetPixel(i,j,0);*/
					//��ȡ�߽磬�����зǺ�ɫ������Ϊ��ɫ
				for(i=2;i<max_x+1;i++)
				for(j=2;j<max_y+1;j++)
							
				if(DC.GetPixel(i,j)!=0)
					DC.SetPixel(i,j,BS);

	
}


void CMapView::OnRidge() 
{
	// TODO: Add your command handler code here
	CClientDC DC(this);
	COLORREF BS=RGB(255,255,255);
	int i;
	int j;
	
	for(i=0;i<max_x+4;i++)
		for(j=0;j<max_y+4;j++)
		{
			if (DC.GetPixel(i,j)==BS)
				
				distance[i][j]=50625;//����ֵ��ֵΪ����ֵ255
			
			
			else
			{
				distance[i][j]=0;//Ŀ����Ԫ������ֵ��ֵΪ0��
			}
			
			DC.SetPixel(i,j,RGB(distance[i][j],0,0));
		}
      for(i=0;i<max_x+4;i++)
		for(j=0;j<max_y+4;j++)
		{
			if(distance[i][j]==0)
			{
			distance[i-1][j]=1;
			distance[i+1][j]=1;
			distance[i][j-1]=1;
			distance[i][j+1]=1;
			distance[i+1][j+1]=2;
			distance[i-1][j+1]=2;
			distance[i+1][j-1]=2;
			distance[i-1][j-1]=2;
			}

		}
		MessageBox("��ʼ������");
		
		for(i=2;i<max_x+1;i++)	
			for(j=2;j<max_y+1;j++)
				
				
			{       double de[6]={50625,50625,50625,50625,50625,50625};	
									
					if(distance[i-1][j]>distance[i-2][j])
					   de[1]=(2*distance[i-1][j]-distance[i-2][j]+2);
				
				/*	if(distance[i-1][j-1]>distance[i-2][j-2])
				       de[2]=(2*distance[i-1][j-1]-distance[i-2][j-2]+4);*/

			        	if(distance[i-1][j-1]<distance[i-1][j]&&distance[i-1][j-1]<distance[i][j-1])
				       de[2]=(distance[i-1][j]+distance[i][j-1]-distance[i-1][j-1]);

					if(distance[i][j-1]>distance[i][j-2])
					   de[3]=(2*distance[i][j-1]-distance[i][j-2]+2);		
	                    			
				/*	if(distance[i-1][j+1]>distance[i-2][j+2])
					   de[4]=(2*distance[i-1][j+1]-distance[i-2][j+2]+4);*/
					if(distance[i-1][j+1]<distance[i-1][j]&&distance[i-1][j+1]<distance[i][j+1])
				       de[4]=(distance[i-1][j]+distance[i][j+1]-distance[i-1][j+1]);
						
				
				int k=0;
			/*	for(k=1;k<5;k++)
				{
					if(de[k]<0||de[k]>50625)
						de[k]=50625;
					
				}*/
				for(k=1;k<5;k++)
				{   
					if(de[k]<distance[i][j])
					{
						distance[i][j]=de[k];
					}
				}
			
			
				DC.SetPixel(i,j,RGB(int(sqrt(distance[i][j])+0.5),0,0));
			}//����ɨ��

		for(i=0;i<max_x+4;i++)
			for(j=0;j<max_y+4;j++)
		{
			if(distance[i][j]==0)

                  DC.SetPixel(i,j,RGB(0,255,0));
		}
			MessageBox("����ɨ�����");
			
		
			
			for(i=max_x;i>1;i--)
				for(j=max_y;j>1;j--)
				{
					
					double de[9]={50625,50625,50625,50625,50625,50625,50625,50625,50625};
				
						if(distance[i+1][j]>distance[i+2][j])
					
							de[5]=(2*distance[i+1][j]-distance[i+2][j]+2);
														
					/*	if(distance[i+1][j+1]>distance[i+2][j+2])
						
							de[6]=(2*distance[i+1][j+1]-distance[i+2][j+2]+4);*/
						if(distance[i+1][j+1]<distance[i+1][j]&&distance[i+1][+j]<distance[i][j+1])
				       de[6]=(distance[i+1][j]+distance[i][j+1]-distance[i+1][j+1]);
									
						if(distance[i][j+1]>distance[i][j+2])
						
							de[7]=(2*distance[i][j+1]-distance[i][j+2]+2);
				
						/*if(distance[i+1][j-1]>distance[i+2][j-2])
						
							de[8]=(2*distance[i+1][j-1]-distance[i+2][j-2]+4);	*/
						if(distance[i+1][j-1]<distance[i-1][j]&&distance[i+1][j]<distance[i][j-1])
				       de[8]=(distance[i+1][j]+distance[i][j-1]-distance[i+1][j-1]);
							
								
					int k=0;
				/*	for(k=5;k<9;k++)
					{
						if(de[k]<0||de[k]>50625)
							
							de[k]=50625;
					}*/
					for(k=5;k<9;k++)
					{   
						
						if(de[k]<distance[i][j])
						{
							distance[i][j]=de[k];
						}
					}
					
					DC.SetPixel(i,j,RGB(int(sqrt(distance[i][j])+0.5),0,0));
				}//����ɨ��
			
				MessageBox("����ɨ�����");
			
			
		
}
void CMapView::OnUpdateXY(CCmdUI* pCmdUI) 

{
	   pCmdUI->Enable(TRUE);	// ʹ�����ı��ܱ�����	
}


void CMapView::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CClientDC DC(this);
	CString str;
	CMainFrame* pFrame=(CMainFrame*)AfxGetApp()->m_pMainWnd;	
	CStatusBar* pStatus=&pFrame->m_wndStatusBar;	
	if (pStatus)
	{
		str.Format("RGB=%d",DC.GetPixel(point));// ��ʽ���ı�		
	pStatus->SetPaneText(1,str);
			str.Format("Y=%d",point.x);
	pStatus->SetPaneText(2,str); 
	
	str.Format("Y=%d",point.y);
	pStatus->SetPaneText(3,str); 
	}
	
	
	CView::OnMouseMove(nFlags, point);
}

void CMapView::OnDistanceY() 
{
	// TODO: Add your command handler code here
	CClientDC DC(this);
	COLORREF BS=RGB(255,255,255);
	int i;
	int j;
	mark de[9];
	
	//DC.TextOut(500,100,"FAS");
	
	if(m_chufa==1)
	{
	for(i=0;i<max_x+3;i++)
		for(j=0;j<max_y+3;j++)
		{
			if (DC.GetPixel(i,j)==BS)
				
			{
				T[i][j].distance=50625;//����ֵ��ֵΪ����ֵ255
                T[i][j].x=50625;
				T[i][j].y=50625;
				T[i][j].w=1;
			}
			
			else
			{
				T[i][j].distance=0;//Ŀ��㸳0
                T[i][j].x=0;
				T[i][j].y=0;
				T[i][j].w=1;
			}
			
		}
	}
	else
	{	if(m_chufa==2)
		{
           for(i=0;i<max_x+3;i++)
		      for(j=0;j<max_y+3;j++)
			  {
                T[i][j].distance=50625;//����ֵ��ֵΪ����ֵ255
                T[i][j].x=50625;
				T[i][j].y=50625;
				T[i][j].w=1;

			  }
			  for(i=0;i<m;i++)
			  {
				  T[m_point[i].x][m_point[i].y].x=0;
				  T[m_point[i].x][m_point[i].y].y=0;
				  T[m_point[i].x][m_point[i].y].w=m_point[i].w;
				  T[m_point[i].x][m_point[i].y].distance=0;


			  }
		}
	}
		MessageBox("��ʼ������fdsafasf");
		
		for(i=2;i<max_x+1;i++)
			for(j=2;j<max_y+1;j++)
			{
				    /*de[0].distance=sqrt(T[i][j].x*T[i][j].x+T[i][j].y*T[i][j].y);
					de[0].x=0;
					de[0].y=0;
					//de[1].w=T[i][j-1].w;*/

				    de[1].distance=sqrt(T[i][j-1].x*T[i][j-1].x+(T[i][j-1].y+1)*(T[i][j-1].y+1));
					de[1].x=T[i][j-1].x;
					de[1].y=T[i][j-1].y+1;
					//de[1].w=T[i][j-1].w;


					de[2].distance=sqrt((T[i-1][j-1].x+1)*(T[i-1][j-1].x+1)+(T[i-1][j-1].y+1)*(T[i-1][j-1].y+1));
                    de[2].x=T[i-1][j-1].x+1;
					de[2].y=T[i-1][j-1].y+1;
					//de[2].w=T[i-1][j-1].w;
						
					de[3].distance=sqrt((T[i-1][j].x+1)*(T[i-1][j].x+1)+(T[i-1][j].y)*(T[i-1][j].y));
                    de[3].x=T[i-1][j].x+1;
					de[3].y=T[i-1][j].y;
					//de[3].w=T[i-1][j].w;

					de[4].distance=sqrt((T[i-1][j+1].x+1)*(T[i-1][j+1].x+1)+(T[i-1][j+1].y+1)*(T[i-1][j+1].y+1));
					de[4].x=T[i-1][j+1].x+1;
					de[4].y=T[i-1][j+1].y+1;
					//de[4].w=T[i-1][j+1].w;

					
				
					
				
				
				int k=0;
				for(k=1;k<5;k++)
				{
					if(de[k].distance<T[i][j].distance)
					{
						T[i][j].distance=de[k].distance;
                        T[i][j].x=de[k].x;
						T[i][j].y=de[k].y;
						//T[i][j].w=de[k].w;


					}
				}
				DC.SetPixel(i,j,RGB(int(T[i][j].distance+0.5),0,0));
			}//����ɨ��
			MessageBox("����ɨ�����");
			for(i=max_x;i>1;i--)
				for(j=max_y;j>1;j--)
				{
					
					
					de[5].distance=sqrt((T[i][j+1].x)*(T[i][j+1].x)+(T[i][j+1].y+1)*(T[i][j+1].y+1));
					de[5].x=T[i][j+1].x;
					de[5].y=T[i][j+1].y+1;
					//de[5].w=T[i][j+1].w;

					de[6].distance=sqrt((T[i+1][j+1].x+1)*(T[i+1][j+1].x+1)+(T[i+1][j+1].y+1)*(T[i+1][j+1].y+1));
					de[6].x=T[i+1][j+1].x+1;
					de[6].y=T[i+1][j+1].y+1;
					//de[6].w=T[i+1][j+1].w;

					de[7].distance=sqrt((T[i+1][j].x+1)*(T[i+1][j].x+1)+(T[i+1][j].y)*(T[i+1][j].y));
					de[7].x=T[i+1][j].x+1;
					de[7].y=T[i+1][j].y;
					//de[7].w=T[i+1][j].w;

					de[8].distance=sqrt((T[i+1][j-1].x+1)*(T[i+1][j-1].x+1)+(T[i+1][j-1].y+1)*(T[i+1][j-1].y+1));
					de[8].x=T[i+1][j-1].x+1;
					de[8].y=T[i+1][j-1].y+1;
					//de[8].w=T[i+1][j-1].w;
					
					int k=0;
					for(k=5;k<9;k++)
					{
					if(de[k].distance<T[i][j].distance)
					{
						T[i][j].distance=de[k].distance;
                        T[i][j].x=de[k].x;
						T[i][j].y=de[k].y;
						//T[i][j].w=de[k].w;


					}
					}
						DC.SetPixel(i,j,RGB(int(T[i][j].distance+0.5),0,0));
				}//����ɨ��

				MessageBox("����ɨ�����");
			
				
			/*	for(i=2;i<max_x+1;i++)
					for(j=2;j<max_y+1;j++)
					{
						DC.SetPixel(i,j,RGB(T[i][j].x,T[i][j].y,0));
					}
					MessageBox("����");*/
				/*	for(i=2;i<max_x+1;i++)
					for(j=2;j<max_y+1;j++)
					{    int l=1;
						if(T[i][j-1].distance=T[i][j+1].distance)
						l=0;
                        if(T[i-1][j-1].distance=T[i+1][j+1].distance)
						l=0;
					    if(T[i-1][j].distance=T[i+1][j].distance)
						l=0;
						if(T[i+1][j-1].distance=T[i-1][j+1].distance)
						l=0;

						if(T[i][j].distance=T[i-1][j+1].distance)
						l=0;
						if(T[i][j].distance=T[i][j+1].distance)
						l=0;
						if(T[i][j].distance=T[i+1][j+1].distance)
						l=0;
						if(T[i][j].distance=T[i+1][j].distance)
						l=0;
						if(T[i][j].distance=T[i+1][j-1].distance)
						l=0;
						if(T[i][j].distance=T[i][j-1].distance)
						l=0;
						if(T[i][j].distance=T[i-1][j-1].distance)
						l=0;
						if(T[i][j].distance=T[i-1][j].distance)
						l=0;
						
				
					
								
					
					if(l=1)
								DC.SetPixel(i,j,RGB(255,255,255));
					else
								DC.SetPixel(i,j,RGB(255,0,0));

					}*/
					
				/*	for(j=2;j<max_y+1;j++)
						for(i=2;i<max_x+1;i++)
					{
						if((T[i][j].distance>=T[i-1][j].distance)&&(T[i][j].distance>=T[i+1][j].distance))||
							DC.SetPixel(i,j,RGB(255,0,0));
						else
							DC.SetPixel(i,j,RGB(255,255,255));

					}*/


	
}

void CMapView::OnAll() 
{
	// TODO: Add your command handler code here
	CClientDC DC(this);
	//CPen*pPen;
	/*pPen=new CPen(PS_SOLID,5,RGB(255,0,0));
	DC.MoveTo(100,100);
	DC.LineTo(300,150);
	delete pPen;
	CPen*pPen2;
	pPen2=new CPen(PS_SOLID,5,RGB(255,0,0));
//	CGdiObject*pOldObject=DC.SelectStockObject(NULL_BRUSH);
	DC.Ellipse(150,150,230,230);
	DC.SetROP2(R2_BLACK);
	DC.FloodFill(190,190,RGB(0,0,0));*/
	for(int i=80;i<130;i++)
	for(int j=80;j<120;j++)
    DC.SetPixel(i,j,68);
	for(int k=70;k<180;k++)
				DC.SetPixel(250,k,90);
		for(int f=70;f<290;f++)
				DC.SetPixel(f,200,80);
	DC.SetPixel(300,100,50);
	DC.SetPixel(150,100,60);
			
	m_chufa=3;			
	max_x=400;
	max_y=240;
}

void CMapView::digui(int i, int j)
{    
	
	if(T[i-1][j].w==T[i][j].w&&T[i-1][j].n==0)
	{T[i-1][j].n=T[i][j].n;digui(i-1,j);}
	if(T[i-1][j-1].w==T[i][j].w&&T[i-1][j-1].n==0){T[i-1][j-1].n=T[i][j].n;digui(i-1,j-1);}
	if(T[i][j-1].w==T[i][j].w&&T[i][j-1].n==0){T[i][j-1].n=T[i][j].n;digui(i,j-1);}
	if(T[i+1][j-1].w==T[i][j].w&&T[i+1][j-1].n==0){T[i+1][j-1].n=T[i][j].n;digui(i+1,j-1);}
	if(T[i+1][j].w==T[i][j].w&&T[i+1][j].n==0){T[i+1][j].n=T[i][j].n;digui(i+1,j);}
	if(T[i+1][j+1].w==T[i][j].w&&T[i+1][j+1].n==0){T[i+1][j+1].n=T[i][j].n;digui(i+1,j+1);}
	if(T[i][j+1].w==T[i][j].w&&T[i][j+1].n==0){T[i][j+1].n=T[i][j].n;digui(i,j+1);}
	if(T[i-1][j+1].w==T[i][j].w&&T[i-1][j+1].n==0){T[i-1][j+1].n=T[i][j].n;digui(i-1,j+1);}
	
}

void CMapView::OnAllV() 
{
	// TODO: Add your command handler code here
	CClientDC DC(this);
	COLORREF BS=RGB(255,255,255);
	int i;
	int j;
	mark de[9];
	
	//DC.TextOut(500,100,"FAS");
	

		if(m_chufa==3)
		{
			for(i=0;i<max_x+3;i++)
				for(j=0;j<max_y+3;j++)
				{    double s=1;
				   s=(DC.GetPixel(i,j))*0.01;
					if (DC.GetPixel(i,j)==BS)
						
					{  
						T[i][j].distance=50625;//����ֵ��ֵΪ����ֵ255
						T[i][j].x=50625;
						T[i][j].y=50625;
						T[i][j].w=1;
						T[i][j].n=0;
					}
					
					else
					{
						T[i][j].distance=0;//Ŀ��㸳0
						T[i][j].x=i;
						T[i][j].y=j;
						T[i][j].w=s;
						T[i][j].n=0;
					}
					
				}
				int k=1;
				for(i=0;i<max_x+3;i++)
				for(j=0;j<max_y+3;j++)
					if(T[i][j].w!=1&&T[i][j].n==0)
					{
                        T[i][j].n=k;
						digui(i,j);
						k++;
					}
		}

		MessageBox("��ʼ������fdsafasf");
		
		for(i=2;i<max_x+1;i++)
			for(j=2;j<max_y+1;j++)
			{
				
				    de[1].distance=sqrt((i-T[i][j-1].x)*(i-T[i][j-1].x)+(j-T[i][j-1].y)*(j-T[i][j-1].y))/T[i][j-1].w;
					de[1].x=T[i][j-1].x;
					de[1].y=T[i][j-1].y;
					de[1].w=T[i][j-1].w;
					de[1].n=T[i][j-1].n;


					de[2].distance=sqrt((i-T[i-1][j-1].x)*(i-T[i-1][j-1].x)+(j-T[i-1][j-1].y)*(j-T[i-1][j-1].y))/T[i-1][j-1].w;
                    de[2].x=T[i-1][j-1].x;
					de[2].y=T[i-1][j-1].y;
					de[2].w=T[i-1][j-1].w;
					de[2].n=T[i-1][j-1].n;
						
					de[3].distance=sqrt((i-T[i-1][j].x)*(i-T[i-1][j].x)+(j-T[i-1][j].y)*(j-T[i-1][j].y))/T[i-1][j].w;
                    de[3].x=T[i-1][j].x;
					de[3].y=T[i-1][j].y;
					de[3].w=T[i-1][j].w;
					de[3].n=T[i-1][j].n;

					de[4].distance=sqrt((i-T[i-1][j+1].x)*(i-T[i-1][j+1].x)+(j-T[i-1][j+1].y)*(j-T[i-1][j+1].y))/T[i-1][j+1].w;
					de[4].x=T[i-1][j+1].x;
					de[4].y=T[i-1][j+1].y;
					de[4].w=T[i-1][j+1].w;
					de[4].n=T[i-1][j+1].n;

					
				
					
				
				
				int k=0;
				for(k=1;k<5;k++)
				{
					if(de[k].distance<T[i][j].distance)
					{
						T[i][j].distance=de[k].distance;
                        T[i][j].x=de[k].x;
						T[i][j].y=de[k].y;
						T[i][j].w=de[k].w;
						T[i][j].n=de[k].n;


					}
				}
				DC.SetPixel(i,j,RGB(int(T[i][j].distance+0.5),0,0));
			}//����ɨ��
			//MessageBox("����ɨ�����");
			for(i=max_x;i>1;i--)
				for(j=max_y;j>1;j--)
				{
					
					
					de[5].distance=sqrt((i-T[i][j+1].x)*(i-T[i][j+1].x)+(j-T[i][j+1].y)*(j-T[i][j+1].y))/T[i][j+1].w;
					de[5].x=T[i][j+1].x;
					de[5].y=T[i][j+1].y;
					de[5].w=T[i][j+1].w;
					de[5].n=T[i][j+1].n;

					de[6].distance=sqrt((i-T[i+1][j+1].x)*(i-T[i+1][j+1].x)+(j-T[i+1][j+1].y)*(j-T[i+1][j+1].y))/T[i+1][j+1].w;
					de[6].x=T[i+1][j+1].x;
					de[6].y=T[i+1][j+1].y;
					de[6].w=T[i+1][j+1].w;
					de[6].n=T[i+1][j+1].n;

					de[7].distance=sqrt((i-T[i+1][j].x)*(i-T[i+1][j].x)+(j-T[i+1][j].y)*(j-T[i+1][j].y))/T[i+1][j].w;
					de[7].x=T[i+1][j].x;
					de[7].y=T[i+1][j].y;
					de[7].w=T[i+1][j].w;
					de[7].n=T[i+1][j].n;

					de[8].distance=sqrt((i-T[i+1][j-1].x)*(i-T[i+1][j-1].x)+(j-T[i+1][j-1].y)*(j-T[i+1][j-1].y))/T[i+1][j-1].w;
					de[8].x=T[i+1][j-1].x;
					de[8].y=T[i+1][j-1].y;
					de[8].w=T[i+1][j-1].w;
					de[8].w=T[i+1][j-1].n;
					
					int k=0;
					for(k=5;k<9;k++)
					{
					if(de[k].distance<T[i][j].distance)
					{
						//T[i][j]=de[k];
                        
                        T[i][j].distance=de[k].distance;
                        T[i][j].x=de[k].x;
						T[i][j].y=de[k].y;
						T[i][j].w=de[k].w;
						T[i][j].n=de[k].n;

					}
					}
				
						DC.SetPixel(i,j,RGB(int(T[i][j].distance+0.5),0,0));
				}//����ɨ�衣���ɾ���任ͼ

				MessageBox("����vͼ");
			
				
				for(i=2;i<max_x+1;i++)
					for(j=2;j<max_y+1;j++)
					{
						DC.SetPixel(i,j,RGB(T[i][j].n*100,T[i][j].n*100,0));
					}
				MessageBox("��ȡ�߽�");

				for(i=2;i<max_x+1;i++)
				for(j=2;j<max_y+1;j++)
					
				if(T[i][j].w!=T[i][j+1].w)
						DC.SetPixel(i,j,0);
				
				for(j=2;j<max_y+1;j++)
				for(i=2;i<max_x+1;i++)	
				if(T[i][j].w!=T[i+1][j].w)
						DC.SetPixel(i,j,0);
					
				for(i=2;i<max_x+1;i++)
				for(j=2;j<max_y+1;j++)
							
				if(DC.GetPixel(i,j)!=0)
					DC.SetPixel(i,j,BS);

				for(i=2;i<max_x+1;i++)
				for(j=2;j<max_y+1;j++)
					if(T[i][j].distance==0)
					DC.SetPixel(i,j,RGB(T[i][j].w*100,T[i][j].w*100,T[i][j].w*100));

	
}
